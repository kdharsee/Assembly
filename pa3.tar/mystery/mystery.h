#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int add(int num1, int num2);
int compute_fib(int number);
