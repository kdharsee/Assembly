
#include "nCr.h"
